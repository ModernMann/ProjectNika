package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.myapplication1.adapter.ClassAdapter;
import com.example.myapplication1.model.Class;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Rasrisanie extends AppCompatActivity {
    RecyclerView classRecycler;
    ClassAdapter classAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rasrisanie);

        List<Class> classList = new ArrayList<>();
        classList.add(new Class(1, "1А"));
        classList.add(new Class(2, "1Б"));
        classList.add(new Class(3, "2А"));
        classList.add(new Class(4, "2Б"));
        classList.add(new Class(5, "3А"));
        classList.add(new Class(6, "3Б"));
        classList.add(new Class(7, "4А"));
        classList.add(new Class(8, "4Б"));
        classList.add(new Class(9, "5А"));
        classList.add(new Class(10, "5Б"));
        classList.add(new Class(11, "6А"));
        classList.add(new Class(12, "6Б"));
        classList.add(new Class(13, "7А"));
        classList.add(new Class(14, "7Б"));
        classList.add(new Class(15, "8А"));
        classList.add(new Class(16, "8Б"));

        setClassRecycler(classList);
    }
    private void  setClassRecycler(List<Class> classList)
    {
      RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);

      classRecycler = findViewById(R.id.classRecucler);
      classRecycler.setLayoutManager(layoutManager);

      classAdapter = new ClassAdapter(this, classList);
      classRecycler.setAdapter(classAdapter);
    }

}